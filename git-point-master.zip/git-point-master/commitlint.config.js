module.exports = {
  extends: ['./.commitlint/'],
};
