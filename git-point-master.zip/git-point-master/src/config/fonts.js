export const fonts = {
  fontPrimaryLight: { fontFamily: 'Nunito-Light' },
  fontPrimary: { fontFamily: 'Nunito-Regular' },
  fontPrimaryItalic: { fontFamily: 'Nunito-Italic' },
  fontPrimarySemiBold: { fontFamily: 'Nunito-SemiBold' },
  fontPrimaryBold: { fontFamily: 'Nunito-Bold' },
  fontCode: { fontFamily: 'Inconsolata-Regular' },
};
