export const common = {
  defaultLocale: 'en',
};
