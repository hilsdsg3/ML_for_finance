export const animations = {
  duration: 100,
  friction: 10,
};
