export default {
  name: 'test label text',
  color: 'c3c3c3',
};
