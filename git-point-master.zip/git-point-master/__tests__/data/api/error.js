export const authError = {
  message: 'Requires authentication',
  documentation_url:
    'https://developer.github.com/v3/activity/notifications/#list-your-notifications',
};
